class Bullet
{
  constructor(x,y)
  {
    this.x=x
    this.y=y
    
  }
  
  draw()
  {
    fill(50,0,200);
   ellipse(this.x,this.y,16,16);
  }
  
 
move(){
  

 this.y=this.y-25;
  
}  
  


}